import DocsLink from './DocsLink'

export {
  DocsLink
}